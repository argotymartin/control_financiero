var CACHE = 'control-financiero-v1';
var URLS = ['/', '/login', '/static/icon-192.png', '/static/icon-512.png'];

self.addEventListener('install', function(e) {
    e.waitUntil(caches.open(CACHE).then(function(cache) {
        return cache.addAll(URLS);
    }));
});

self.addEventListener('fetch', function(e) {
    e.respondWith(
        fetch(e.request).catch(function() {
            return caches.match(e.request);
        })
    );
});
