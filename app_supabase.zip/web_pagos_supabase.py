#!/usr/bin/env python3
"""
App Web - Control Financiero (Version Supabase)
Misma funcionalidad que web_pagos.py pero usando Supabase como backend.
Plantillas en templates/ con herencia Jinja2.
"""
from flask import (Flask, render_template, request, redirect,
                   url_for, flash, send_file, session, jsonify)
from functools import wraps
import hashlib
from datetime import datetime
import json
import os
import re
import smtplib
import tempfile
import zipfile
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from io import BytesIO

import base64
import pytesseract
from PIL import Image
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
import face_recognition
import numpy as np
from supabase import create_client

# ==================== CONFIGURACION SUPABASE ====================
SUPABASE_URL = os.environ.get('SUPABASE_URL', '')
SUPABASE_KEY = os.environ.get('SUPABASE_KEY', '')

if not SUPABASE_URL or not SUPABASE_KEY:
    print("=" * 60)
    print("  ERROR: Configura las variables de entorno:")
    print("    export SUPABASE_URL='https://tu-proyecto.supabase.co'")
    print("    export SUPABASE_KEY='tu-service-role-key'")
    print("=" * 60)
    exit(1)

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

CORREO_REMITENTE = os.environ.get('CORREO_REMITENTE', 'argoty.martin@gmail.com')
CORREO_CLAVE_APP = os.environ.get('CORREO_CLAVE_APP', 'vbzs yrtk auhr quya')

MESES = {
    'enero': '01', 'febrero': '02', 'marzo': '03', 'abril': '04',
    'mayo': '05', 'junio': '06', 'julio': '07', 'agosto': '08',
    'septiembre': '09', 'octubre': '10', 'noviembre': '11', 'diciembre': '12'
}

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'pagos_liliana_supabase_2024')


# ==================== CONTEXT PROCESSOR ====================
# Inyecta fecha_desde y fecha_hasta en todas las plantillas automaticamente

@app.context_processor
def inyectar_fechas():
    if 'usuario' in session:
        datos_raw = cargar_pagos()
        fd, fh = get_fechas(datos_raw)
        return {'fecha_desde': fd, 'fecha_hasta': fh}
    return {'fecha_desde': '', 'fecha_hasta': ''}


# ==================== FUNCIONES DE BASE DE DATOS ====================

def hash_clave(clave):
    return hashlib.sha256(clave.encode()).hexdigest()


def cargar_usuarios():
    resp = supabase.table('usuarios').select('*').execute()
    return {u['usuario']: u for u in resp.data}


def guardar_usuario(usuario_id, datos_actualizar):
    supabase.table('usuarios').update(datos_actualizar).eq('usuario', usuario_id).execute()


def cargar_pagos():
    resp = supabase.table('pagos').select('*').order('id').execute()
    return resp.data


def guardar_pago(pago):
    supabase.table('pagos').insert(pago).execute()


def eliminar_pago(pago_id):
    supabase.table('pagos').delete().eq('id', pago_id).execute()


def cargar_destinatarios():
    resp = supabase.table('destinatarios').select('correo').execute()
    return [d['correo'] for d in resp.data]


def agregar_destinatario_db(correo):
    supabase.table('destinatarios').insert({'correo': correo}).execute()


def quitar_destinatario_db(correo):
    supabase.table('destinatarios').delete().eq('correo', correo).execute()


def obtener_no_vistos(usuario):
    pagos = cargar_pagos()
    pagos_con_imagen = [p for p in pagos if p.get('imagen')]
    if not pagos_con_imagen:
        return 0
    vistos = supabase.table('pagos_vistos').select('pago_id').eq('usuario', usuario).execute()
    ids_vistos = {v['pago_id'] for v in vistos.data}
    return sum(1 for p in pagos_con_imagen if p['id'] not in ids_vistos)


def marcar_visto(usuario, pago_id):
    supabase.table('pagos_vistos').upsert({
        'usuario': usuario,
        'pago_id': pago_id
    }).execute()


# ==================== SUPABASE STORAGE ====================

def subir_imagen_storage(bucket, nombre, datos_bytes, content_type='image/jpeg'):
    supabase.storage.from_(bucket).upload(
        nombre, datos_bytes,
        file_options={"content-type": content_type, "upsert": "true"}
    )


def obtener_url_publica(bucket, nombre):
    return supabase.storage.from_(bucket).get_public_url(nombre)


def descargar_imagen_storage(bucket, nombre):
    return supabase.storage.from_(bucket).download(nombre)


def guardar_imagen_base64(imagen_base64, ruta):
    datos_img = base64.b64decode(imagen_base64.split(',')[1])
    with open(ruta, 'wb') as f:
        f.write(datos_img)


def obtener_encoding_facial(ruta):
    img = face_recognition.load_image_file(ruta)
    encodings = face_recognition.face_encodings(img)
    return encodings[0] if encodings else None


def registrar_rostro(usuario, imagen_base64):
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp:
        ruta_foto = tmp.name
        datos_img = base64.b64decode(imagen_base64.split(',')[1])
        tmp.write(datos_img)

    encoding = obtener_encoding_facial(ruta_foto)
    if encoding is None:
        os.remove(ruta_foto)
        return False

    # Subir foto al Storage de Supabase
    with open(ruta_foto, 'rb') as f:
        subir_imagen_storage('rostros', f'{usuario}.jpg', f.read())
    os.remove(ruta_foto)

    # Guardar encoding en la base de datos
    guardar_usuario(usuario, {'rostro': json.dumps(encoding.tolist())})
    return True


def verificar_rostro(imagen_base64):
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as tmp:
        ruta_temp = tmp.name
        datos_img = base64.b64decode(imagen_base64.split(',')[1])
        tmp.write(datos_img)

    encoding_login = obtener_encoding_facial(ruta_temp)
    os.remove(ruta_temp)
    if encoding_login is None:
        return None

    usuarios = cargar_usuarios()
    for usuario, datos in usuarios.items():
        if datos.get('rostro'):
            rostro_data = datos['rostro']
            if isinstance(rostro_data, str):
                rostro_data = json.loads(rostro_data)
            encoding_guardado = np.array(rostro_data)
            resultado = face_recognition.compare_faces([encoding_guardado], encoding_login, tolerance=0.6)
            if resultado[0]:
                return usuario
    return None


# ==================== AUTENTICACION ====================

def login_requerido(f):
    @wraps(f)
    def decorador(*args, **kwargs):
        if 'usuario' not in session:
            flash('Debes iniciar sesion para acceder.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorador


def admin_requerido(f):
    @wraps(f)
    @login_requerido
    def decorador(*args, **kwargs):
        if session.get('usuario') != 'admin':
            flash('Solo el administrador puede acceder a esta funcion.', 'error')
            return redirect(url_for('inicio'))
        return f(*args, **kwargs)
    return decorador


# ==================== OCR ====================

def extraer_datos_imagen(ruta_imagen):
    img = Image.open(ruta_imagen)
    texto = pytesseract.image_to_string(img, lang='spa')

    datos = {'fecha': '', 'valor': 0, 'medio': '', 'referencia': '', 'observacion': ''}

    es_nequi = 'nequi' in texto.lower() or 'envío realizado' in texto.lower() or 'envio recibido' in texto.lower() or 'envío recibido' in texto.lower()
    es_banco_bogota = 'banco de bogotá' in texto.lower() or 'banco de bogota' in texto.lower()
    es_transfiya = 'transfiya' in texto.lower()

    patron_valor = re.search(r'\$\s*([\d.,]+)', texto)
    if patron_valor:
        val_str = patron_valor.group(1).replace('.', '').replace(',', '')
        if len(val_str) > 2 and val_str.endswith('00'):
            val_str = val_str[:-2]
        try:
            datos['valor'] = int(val_str)
        except ValueError:
            pass

    patron_fecha_nequi = re.search(r'(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})', texto, re.IGNORECASE)
    patron_fecha_banco = re.search(r'(\w+)\s+(\d{1,2})\s+del\s+(\d{4})', texto, re.IGNORECASE)
    patron_fecha_alt = re.search(r'(\d{1,2})\s+de\s+(\w+)\s+del\s+(\d{4})', texto, re.IGNORECASE)

    if patron_fecha_nequi:
        dia = patron_fecha_nequi.group(1).zfill(2)
        mes = MESES.get(patron_fecha_nequi.group(2).lower(), '00')
        datos['fecha'] = f'{patron_fecha_nequi.group(3)}-{mes}-{dia}'
    elif patron_fecha_banco:
        mes = MESES.get(patron_fecha_banco.group(1).lower(), '00')
        dia = patron_fecha_banco.group(2).zfill(2)
        datos['fecha'] = f'{patron_fecha_banco.group(3)}-{mes}-{dia}'
    elif patron_fecha_alt:
        dia = patron_fecha_alt.group(1).zfill(2)
        mes = MESES.get(patron_fecha_alt.group(2).lower(), '00')
        datos['fecha'] = f'{patron_fecha_alt.group(3)}-{mes}-{dia}'

    if es_nequi and es_transfiya:
        datos['medio'] = 'Banco de Bogota / Transfiya'
    elif es_nequi and es_banco_bogota:
        datos['medio'] = 'Banco de Bogota / Nequi'
    elif es_nequi:
        datos['medio'] = 'Nequi'
    elif es_transfiya:
        datos['medio'] = 'Banco de Bogota / Transfiya'
    elif es_banco_bogota:
        datos['medio'] = 'Banco de Bogota'
    else:
        datos['medio'] = 'Otro'

    patron_ref_nequi = re.search(r'[Rr]eferencia\s*\n?\s*(\S+)', texto)
    patron_ref_banco = re.search(r'autorizaci[oó]n[:\s]*\n?\s*(\S+)', texto, re.IGNORECASE)
    patron_comprobante = re.search(r'[Cc]omprobante\s*\n?\s*(\d{10,})', texto)

    if patron_ref_nequi:
        ref = re.sub(r'^[^A-Za-z0-9]+', '', patron_ref_nequi.group(1).strip())
        datos['referencia'] = ref
    elif patron_ref_banco:
        datos['referencia'] = patron_ref_banco.group(1).strip()
    elif patron_comprobante:
        datos['referencia'] = patron_comprobante.group(1).strip()

    patron_para = re.search(r'(?:Para|De)\s*\n\s*(.+)', texto)
    patron_destino = re.search(r'[Cc]uenta destino[:\s]*\n?\s*(.+)', texto)
    patron_nota = re.search(r'[Nn]ota[:\s]*\n?\s*(.+)', texto)

    obs_partes = []
    if patron_para:
        obs_partes.append(patron_para.group(1).strip())
    if patron_destino:
        obs_partes.append('Destino: ' + patron_destino.group(1).strip())
    if patron_nota:
        obs_partes.append('Nota: ' + patron_nota.group(1).strip())
    datos['observacion'] = ' - '.join(obs_partes) if obs_partes else ''

    return datos


# ==================== EXCEL ====================

def generar_excel(pagos):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Control Financiero"

    header_font = Font(bold=True, size=12, color="FFFFFF")
    header_fill = PatternFill(start_color="2E75B6", end_color="2E75B6", fill_type="solid")
    border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    title_font = Font(bold=True, size=14)
    link_font = Font(color="0563C1", underline="single")
    rojo = Font(color="DC3545")
    verde = Font(color="28A745")

    ws.merge_cells('A1:J1')
    ws['A1'] = 'Control Financiero'
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center')

    ws.merge_cells('A2:J2')
    if pagos:
        fecha_desde = pagos[0].get('fecha', '')
        fecha_hasta = pagos[-1].get('fecha', '')
        ws['A2'] = f'Desde: {fecha_desde}  -  Hasta: {fecha_hasta}'
    else:
        ws['A2'] = ''
    ws['A2'].alignment = Alignment(horizontal='center')

    headers = ['No.', 'Fecha', 'Concepto', 'Debito', 'Credito', 'Saldo',
               'Medio de Pago', 'Referencia', 'Observaciones', 'Comprobante']
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = border

    saldo = 0
    total_debitos = 0
    total_creditos = 0
    for i, pago in enumerate(pagos):
        row = i + 5
        tipo = pago.get('tipo', 'egreso')
        valor = pago['valor']
        debito = valor if tipo == 'egreso' else 0
        credito = valor if tipo == 'ingreso' else 0
        saldo += credito - debito
        total_debitos += debito
        total_creditos += credito

        ws.cell(row=row, column=1, value=i + 1).border = border
        ws.cell(row=row, column=1).alignment = Alignment(horizontal='center')
        ws.cell(row=row, column=2, value=pago['fecha']).border = border
        ws.cell(row=row, column=2).alignment = Alignment(horizontal='center')
        ws.cell(row=row, column=3, value=pago.get('concepto', '')).border = border

        cell_deb = ws.cell(row=row, column=4, value=debito if debito else None)
        cell_deb.border = border
        cell_deb.number_format = '$#,##0'
        cell_deb.alignment = Alignment(horizontal='right')
        if debito:
            cell_deb.font = rojo

        cell_cred = ws.cell(row=row, column=5, value=credito if credito else None)
        cell_cred.border = border
        cell_cred.number_format = '$#,##0'
        cell_cred.alignment = Alignment(horizontal='right')
        if credito:
            cell_cred.font = verde

        cell_saldo = ws.cell(row=row, column=6, value=saldo)
        cell_saldo.border = border
        cell_saldo.number_format = '$#,##0'
        cell_saldo.alignment = Alignment(horizontal='right')
        cell_saldo.font = verde if saldo >= 0 else rojo

        ws.cell(row=row, column=7, value=pago.get('medio', '')).border = border
        ws.cell(row=row, column=8, value=pago.get('referencia', '')).border = border
        ws.cell(row=row, column=9, value=pago.get('observacion', '')).border = border

        if pago.get('imagen'):
            cell_link = ws.cell(row=row, column=10, value='Ver comprobante')
            url_img = obtener_url_publica('comprobantes', pago['imagen'])
            cell_link.hyperlink = url_img
            cell_link.font = link_font
            cell_link.alignment = Alignment(horizontal='center')
            cell_link.border = border

    total_row = 5 + len(pagos)
    ws.cell(row=total_row, column=1, value='TOTAL').font = Font(bold=True, size=11)
    for col in range(1, 11):
        ws.cell(row=total_row, column=col).border = border

    cell_td = ws.cell(row=total_row, column=4, value=total_debitos)
    cell_td.number_format = '$#,##0'
    cell_td.font = Font(bold=True, size=11, color="DC3545")
    cell_td.alignment = Alignment(horizontal='right')

    cell_tc = ws.cell(row=total_row, column=5, value=total_creditos)
    cell_tc.number_format = '$#,##0'
    cell_tc.font = Font(bold=True, size=11, color="28A745")
    cell_tc.alignment = Alignment(horizontal='right')

    cell_ts = ws.cell(row=total_row, column=6, value=saldo)
    cell_ts.number_format = '$#,##0'
    cell_ts.font = Font(bold=True, size=11)
    cell_ts.alignment = Alignment(horizontal='right')

    ws.cell(row=total_row, column=9, value=f'{len(pagos)} movimientos')

    anchos = {'A': 8, 'B': 14, 'C': 22, 'D': 16, 'E': 16, 'F': 16,
              'G': 28, 'H': 28, 'I': 40, 'J': 18}
    for col, ancho in anchos.items():
        ws.column_dimensions[col].width = ancho

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer, saldo


# ==================== CLASE MOVIMIENTO ====================

class Movimiento:
    def __init__(self, datos):
        self.id = datos.get('id', 0)
        self.fecha = datos.get('fecha', '')
        self.valor = datos.get('valor', 0)
        self.tipo = datos.get('tipo', 'egreso')
        self.concepto = datos.get('concepto', '')
        self.medio = datos.get('medio', '')
        self.referencia = datos.get('referencia', '')
        self.observacion = datos.get('observacion', '')
        self.imagen = datos.get('imagen', '')
        self.imagen_url = obtener_url_publica('comprobantes', self.imagen) if self.imagen else ''

    @property
    def debito(self):
        return self.valor if self.tipo == 'egreso' else 0

    @property
    def credito(self):
        return self.valor if self.tipo == 'ingreso' else 0


def get_fechas(pagos_raw):
    if pagos_raw:
        return pagos_raw[0].get('fecha', ''), pagos_raw[-1].get('fecha', '')
    return '', ''


# ==================== RUTAS ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form.get('usuario', '').strip()
        clave = request.form.get('clave', '')
        usuarios = cargar_usuarios()
        if usuario in usuarios and usuarios[usuario]['clave'] == hash_clave(clave):
            session['usuario'] = usuario
            session['nombre'] = usuarios[usuario]['nombre']
            flash(f'Bienvenido(a), {usuarios[usuario]["nombre"]}.', 'exito')
            return redirect(url_for('inicio'))
        flash('Usuario o contrasena incorrectos.', 'error')
        return redirect(url_for('login'))
    return render_template('paginas/login.html')


@app.route('/login-facial', methods=['POST'])
def login_facial():
    datos = request.get_json()
    foto = datos.get('foto', '')
    if not foto:
        return jsonify(ok=False, error='No se recibio la foto'), 400
    usuario = verificar_rostro(foto)
    if usuario:
        usuarios = cargar_usuarios()
        session['usuario'] = usuario
        session['nombre'] = usuarios[usuario]['nombre']
        return jsonify(ok=True, nombre=usuarios[usuario]['nombre'])
    return jsonify(ok=False, error='Rostro no reconocido')


@app.route('/logout')
def logout():
    session.clear()
    flash('Sesion cerrada correctamente.', 'exito')
    return redirect(url_for('login'))


@app.route('/usuarios')
@admin_requerido
def usuarios():
    usuarios_dict = cargar_usuarios()
    return render_template('paginas/usuarios.html', usuarios=usuarios_dict)


@app.route('/crear-usuario', methods=['POST'])
@admin_requerido
def crear_usuario():
    usuario = request.form.get('usuario', '').strip().lower()
    nombre = request.form.get('nombre', '').strip()
    clave = request.form.get('clave', '')
    if not usuario or not nombre or not clave:
        flash('Todos los campos son obligatorios.', 'error')
        return redirect(url_for('usuarios'))
    if len(clave) < 4:
        flash('La contrasena debe tener al menos 4 caracteres.', 'error')
        return redirect(url_for('usuarios'))
    usuarios_dict = cargar_usuarios()
    if usuario in usuarios_dict:
        flash(f'El usuario "{usuario}" ya existe.', 'error')
        return redirect(url_for('usuarios'))

    supabase.table('usuarios').insert({
        'usuario': usuario,
        'nombre': nombre,
        'clave': hash_clave(clave)
    }).execute()

    foto_rostro = request.form.get('foto_rostro', '')
    msg_rostro = ''
    if foto_rostro:
        if registrar_rostro(usuario, foto_rostro):
            msg_rostro = ' con reconocimiento facial activado'
        else:
            msg_rostro = ' (no se detecto un rostro en la foto, se puede registrar despues)'
    flash(f'Usuario "{usuario}" creado exitosamente{msg_rostro}.', 'exito')
    return redirect(url_for('usuarios'))


@app.route('/registrar-rostro', methods=['POST'])
@admin_requerido
def registrar_rostro_ruta():
    datos = request.get_json()
    usuario = datos.get('usuario', '')
    foto = datos.get('foto', '')
    if not usuario or not foto:
        return jsonify(ok=False, error='Datos incompletos')
    usuarios_dict = cargar_usuarios()
    if usuario not in usuarios_dict:
        return jsonify(ok=False, error='Usuario no existe')
    if registrar_rostro(usuario, foto):
        return jsonify(ok=True)
    return jsonify(ok=False, error='No se detecto un rostro en la foto. Intenta de nuevo.')


@app.route('/eliminar-usuario', methods=['POST'])
@admin_requerido
def eliminar_usuario():
    usuario = request.form.get('usuario', '').strip()
    if usuario == 'admin':
        flash('No se puede eliminar al administrador.', 'error')
        return redirect(url_for('usuarios'))
    supabase.table('usuarios').delete().eq('usuario', usuario).execute()
    flash(f'Usuario "{usuario}" eliminado.', 'exito')
    return redirect(url_for('usuarios'))


@app.route('/')
@login_requerido
def inicio():
    datos_raw = cargar_pagos()
    movimientos = [Movimiento(p) for p in datos_raw]
    total_ingresos = sum(m.credito for m in movimientos)
    total_egresos = sum(m.debito for m in movimientos)
    saldo = total_ingresos - total_egresos
    es_admin = session.get('usuario') == 'admin'
    vistos_resp = supabase.table('pagos_vistos').select('pago_id').eq('usuario', session['usuario']).execute()
    ids_vistos = {v['pago_id'] for v in vistos_resp.data}
    no_vistos = sum(1 for m in movimientos if m.imagen and m.id not in ids_vistos)
    return render_template('paginas/inicio.html', movimientos=movimientos,
                           total_ingresos=total_ingresos, total_egresos=total_egresos,
                           saldo=saldo, es_admin=es_admin, ids_vistos=ids_vistos,
                           no_vistos=no_vistos)


@app.route('/foto-usuario/<usuario>')
@login_requerido
def foto_usuario(usuario):
    try:
        url = obtener_url_publica('rostros', f'{usuario}.jpg')
        return redirect(url)
    except Exception:
        return '', 404


@app.route('/nuevo')
@login_requerido
def nuevo():
    return render_template('paginas/nuevo.html', datos=None)


@app.route('/procesar-imagen', methods=['POST'])
@login_requerido
def procesar_imagen():
    if 'imagen' not in request.files:
        flash('No se selecciono ninguna imagen.', 'error')
        return redirect(url_for('nuevo'))

    archivo = request.files['imagen']
    if archivo.filename == '':
        flash('No se selecciono ninguna imagen.', 'error')
        return redirect(url_for('nuevo'))

    nombre = archivo.filename

    with tempfile.NamedTemporaryFile(suffix=os.path.splitext(nombre)[1], delete=False) as tmp:
        ruta_temp = tmp.name
        archivo.save(ruta_temp)

    try:
        datos = extraer_datos_imagen(ruta_temp)
        datos['imagen'] = nombre

        with open(ruta_temp, 'rb') as f:
            subir_imagen_storage('comprobantes', nombre, f.read())
    except Exception as e:
        flash(f'Error al leer la imagen con OCR: {e}', 'error')
        return redirect(url_for('nuevo'))
    finally:
        os.remove(ruta_temp)

    pagos = cargar_pagos()
    for p in pagos:
        if p.get('imagen') == nombre:
            flash(f'Esta imagen ya fue registrada (Fecha: {p["fecha"]}, Valor: ${p["valor"]:,.0f}).', 'error')
            return redirect(url_for('nuevo'))
        if datos['referencia'] and p.get('referencia') == datos['referencia']:
            flash(f'Ya existe un pago con la misma referencia: {datos["referencia"]}.', 'error')
            return redirect(url_for('nuevo'))

    return render_template('paginas/nuevo.html', datos=datos)


@app.route('/agregar', methods=['POST'])
@login_requerido
def agregar():
    fecha = request.form.get('fecha', '').strip()
    valor_str = request.form.get('valor', '0').strip().replace('.', '').replace(',', '').replace('$', '')
    tipo = request.form.get('tipo', 'egreso').strip()
    concepto = request.form.get('concepto', '').strip()
    medio = request.form.get('medio', '').strip()
    referencia = request.form.get('referencia', '').strip()
    observacion = request.form.get('observacion', '').strip()
    imagen = request.form.get('imagen', '').strip()

    if not fecha or not valor_str:
        flash('Fecha y Valor son obligatorios.', 'error')
        return redirect(url_for('nuevo'))

    try:
        valor = int(valor_str)
    except ValueError:
        flash('El valor debe ser un numero.', 'error')
        return redirect(url_for('nuevo'))

    movimiento = {
        'fecha': fecha, 'valor': valor, 'tipo': tipo, 'concepto': concepto,
        'medio': medio, 'referencia': referencia, 'observacion': observacion,
        'imagen': imagen
    }

    guardar_pago(movimiento)

    pagos = cargar_pagos()
    etiqueta = 'Ingreso' if tipo == 'ingreso' else 'Egreso'
    flash(f'{etiqueta} #{len(pagos)} por ${valor:,.0f} registrado correctamente.', 'exito')
    return redirect(url_for('inicio'))


@app.route('/eliminar/<int:pago_id>', methods=['POST'])
@login_requerido
def eliminar(pago_id):
    eliminar_pago(pago_id)
    flash('Movimiento eliminado.', 'exito')
    return redirect(url_for('inicio'))


@app.route('/descargar-excel')
@login_requerido
def descargar_excel():
    pagos = cargar_pagos()
    if not pagos:
        flash('No hay movimientos registrados.', 'error')
        return redirect(url_for('inicio'))
    buffer, saldo = generar_excel(pagos)
    return send_file(buffer, as_attachment=True, download_name='control_financiero.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@app.route('/correo')
@login_requerido
def correo():
    pagos = cargar_pagos()
    total_ingresos = sum(p['valor'] for p in pagos if p.get('tipo', 'egreso') == 'ingreso')
    total_egresos = sum(p['valor'] for p in pagos if p.get('tipo', 'egreso') == 'egreso')
    saldo = total_ingresos - total_egresos
    destinatarios = cargar_destinatarios()
    return render_template('paginas/correo.html', total=saldo, num_pagos=len(pagos),
                           remitente=CORREO_REMITENTE, destinatarios=destinatarios)


@app.route('/agregar-destinatario', methods=['POST'])
@login_requerido
def agregar_destinatario():
    correo_nuevo = request.form.get('correo', '').strip().lower()
    if not correo_nuevo or '@' not in correo_nuevo:
        flash('Escribe un correo valido.', 'error')
        return redirect(url_for('correo'))

    destinatarios = cargar_destinatarios()
    if correo_nuevo in destinatarios:
        flash('Ese correo ya esta en la lista.', 'info')
        return redirect(url_for('correo'))

    agregar_destinatario_db(correo_nuevo)
    flash(f'Se agrego {correo_nuevo}.', 'exito')
    return redirect(url_for('correo'))


@app.route('/quitar-destinatario', methods=['POST'])
@login_requerido
def quitar_destinatario():
    correo_quitar = request.form.get('correo', '')
    quitar_destinatario_db(correo_quitar)
    flash(f'Se quito {correo_quitar}.', 'exito')
    return redirect(url_for('correo'))


@app.route('/enviar-correo', methods=['POST'])
@login_requerido
def enviar_correo():
    pagos = cargar_pagos()
    if not pagos:
        flash('No hay movimientos registrados.', 'error')
        return redirect(url_for('correo'))

    destinatarios = cargar_destinatarios()
    if not destinatarios:
        flash('Agrega al menos un destinatario.', 'error')
        return redirect(url_for('correo'))

    buffer_excel, saldo = generar_excel(pagos)

    try:
        msg = MIMEMultipart()
        msg['From'] = CORREO_REMITENTE
        msg['To'] = ', '.join(destinatarios)
        msg['Subject'] = f'Control Financiero - {len(pagos)} movimientos - Saldo: ${saldo:,.0f}'

        cuerpo = (
            f"Control Financiero (Supabase)\n"
            f"{'=' * 50}\n\n"
            f"Total movimientos: {len(pagos)}\n"
            f"Saldo actual: ${saldo:,.0f}\n"
            f"Fecha de envio: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
            f"Se adjunta un ZIP con el Excel y todos los comprobantes.\n"
        )
        msg.attach(MIMEText(cuerpo, 'plain'))

        zip_buffer = BytesIO()
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('control_financiero.xlsx', buffer_excel.read())
            for pago in pagos:
                if pago.get('imagen'):
                    try:
                        img_bytes = descargar_imagen_storage('comprobantes', pago['imagen'])
                        zf.writestr(pago['imagen'], img_bytes)
                    except Exception:
                        pass

        zip_buffer.seek(0)
        adjunto_zip = MIMEBase('application', 'octet-stream')
        adjunto_zip.set_payload(zip_buffer.read())
        encoders.encode_base64(adjunto_zip)
        adjunto_zip.add_header('Content-Disposition',
                               'attachment', filename='control_financiero.zip')
        msg.attach(adjunto_zip)

        servidor = smtplib.SMTP('smtp.gmail.com', 587)
        servidor.starttls()
        servidor.login(CORREO_REMITENTE, CORREO_CLAVE_APP)
        servidor.sendmail(CORREO_REMITENTE, destinatarios, msg.as_string())
        servidor.quit()

        destinos = ', '.join(destinatarios)
        flash(f'Correo enviado exitosamente a: {destinos}', 'exito')

    except Exception as e:
        flash(f'Error al enviar correo: {e}', 'error')

    return redirect(url_for('correo'))


@app.route('/marcar-visto/<int:pago_id>', methods=['POST'])
@login_requerido
def marcar_visto_ruta(pago_id):
    marcar_visto(session['usuario'], pago_id)
    no_vistos = obtener_no_vistos(session['usuario'])
    return jsonify(ok=True, no_vistos=no_vistos)


@app.route('/no-vistos')
@login_requerido
def no_vistos_ruta():
    no_vistos = obtener_no_vistos(session['usuario'])
    return jsonify(no_vistos=no_vistos)


@app.route('/sw.js')
def service_worker():
    return app.send_static_file('sw.js'), 200, {'Content-Type': 'application/javascript'}


if __name__ == '__main__':
    print("=" * 50)
    print("  Control Financiero (Supabase)")
    print("  Abre en tu navegador: http://localhost:5052")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5052, debug=True)
